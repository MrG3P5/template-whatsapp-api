# -*- coding: utf-8 -*-

__version__ = "9.6.4"

if __name__ == "__main__":
    print(__version__)
